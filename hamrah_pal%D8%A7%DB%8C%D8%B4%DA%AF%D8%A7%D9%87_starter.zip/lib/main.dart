import 'package:flutter/material.dart';

void main() => runApp(const HamrahApp());

class HamrahApp extends StatelessWidget {
  const HamrahApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'همراه پالایشگاه',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B57)),
        fontFamily: 'Roboto',
      ),
      home: const HomePage(),
    );
  }
}

class StopPoint {
  final String name;
  final String time;
  final int waiting;
  final bool completed;
  const StopPoint(this.name, this.time, this.waiting, {this.completed = false});
}

const demoStops = <StopPoint>[
  StopPoint('میدان اصلی', '۰۷:۰۰', 2, completed: true),
  StopPoint('دروازه غربی', '۰۷:۰۸', 3),
  StopPoint('ورودی واحد عملیاتی', '۰۷:۱۶', 1),
  StopPoint('محل کار — مقصد نهایی', '۰۷:۲۵', 0),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String role = 'مسافر';
  int selectedStop = 1;
  bool routeAlert = false;
  int onboard = 10;
  final int capacity = 16;

  @override
  Widget build(BuildContext context) {
    final isDriver = role == 'راننده';
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('همراه پالایشگاه'),
          actions: [
            IconButton(
              tooltip: 'اعلان‌ها',
              onPressed: () => _message('اعلان‌ها در نسخه متصل به سرور فعال می‌شوند.'),
              icon: const Icon(Icons.notifications_none),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                gradient: const LinearGradient(
                  colors: [Color(0xFF176B57), Color(0xFF23967A)],
                ),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('سامانه هوشمند رفت‌وآمد', style: TextStyle(color: Colors.white70)),
                  SizedBox(height: 8),
                  Text('سرویس شماره ۱۲', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
                  SizedBox(height: 5),
                  Text('مسیر نمونه به سمت پالایشگاه', style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'مسافر', label: Text('مسافر'), icon: Icon(Icons.person_outline)),
                ButtonSegment(value: 'راننده', label: Text('راننده'), icon: Icon(Icons.directions_bus_outlined)),
                ButtonSegment(value: 'مدیر', label: Text('مدیر'), icon: Icon(Icons.admin_panel_settings_outlined)),
              ],
              selected: {role},
              onSelectionChanged: (v) => setState(() => role = v.first),
            ),
            const SizedBox(height: 16),
            if (isDriver) _driverPanel() else if (role == 'مدیر') _adminPanel() else _passengerPanel(),
            const SizedBox(height: 16),
            _routeCard(),
            const SizedBox(height: 16),
            if (isDriver)
              FilledButton.icon(
                onPressed: () => _message('در نسخه آزمایشی، شروع GPS واقعی هنوز متصل نشده است.'),
                icon: const Icon(Icons.my_location),
                label: const Text('شروع سرویس و ردیابی GPS'),
              ),
            if (role == 'مسافر')
              OutlinedButton.icon(
                onPressed: () => _message('در نسخه آزمایشی درخواست شما فقط نمایشی است.'),
                icon: const Icon(Icons.directions_bus),
                label: const Text('انتخاب این سرویس'),
              ),
            if (role == 'مدیر')
              FilledButton.icon(
                onPressed: () => _message('ثبت مسیر و ایستگاه‌ها پس از اتصال به پایگاه داده فعال می‌شود.'),
                icon: const Icon(Icons.add_location_alt_outlined),
                label: const Text('تعریف مسیر / ایستگاه'),
              ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => setState(() => routeAlert = !routeAlert),
              icon: const Icon(Icons.flag_outlined),
              label: Text(routeAlert ? 'لغو گزارش آزمایشی انحراف مسیر' : 'گزارش انحراف مسیر / مشکل سرویس'),
            ),
            if (routeAlert)
              const Card(
                child: ListTile(
                  leading: Icon(Icons.warning_amber_rounded, color: Colors.deepOrange),
                  title: Text('گزارش آزمایشی ثبت شد'),
                  subtitle: Text('در نسخه عملیاتی، گزارش همراه با زمان و مختصات برای مدیر ارسال می‌شود.'),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _passengerPanel() => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('وضعیت سرویس', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 12),
        const Row(children: [
          Icon(Icons.near_me, color: Colors.teal),
          SizedBox(width: 8),
          Expanded(child: Text('موقعیت زنده خودرو پس از اتصال GPS نمایش داده می‌شود')),
        ]),
        const SizedBox(height: 10),
        const Row(children: [
          Icon(Icons.access_time),
          SizedBox(width: 8),
          Expanded(child: Text('زمان رسیدن فعلاً نمونه است؛ ETA واقعی نیازمند GPS و موتور مسیر‌یابی است.')),
        ]),
        const SizedBox(height: 12),
        DropdownButtonFormField<int>(
          value: selectedStop,
          decoration: const InputDecoration(labelText: 'ایستگاه سوار شدن', border: OutlineInputBorder()),
          items: List.generate(demoStops.length - 1, (i) => DropdownMenuItem(
            value: i,
            child: Text(demoStops[i].name),
          )),
          onChanged: (v) => setState(() => selectedStop = v ?? 0),
        ),
      ]),
    ),
  );

  Widget _driverPanel() => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('داشبورد راننده', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 12),
        Row(children: [
          const Icon(Icons.event_seat_outlined),
          const SizedBox(width: 8),
          Text('$onboard نفر از $capacity نفر'),
          const Spacer(),
          Text('${capacity - onboard} صندلی خالی', style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 10),
        LinearProgressIndicator(value: onboard / capacity, minHeight: 8, borderRadius: BorderRadius.circular(8)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, children: [
          OutlinedButton(onPressed: onboard > 0 ? () => setState(() => onboard--) : null, child: const Text('ثبت پیاده‌شدن −۱')),
          FilledButton(onPressed: onboard < capacity ? () => setState(() => onboard++) : null, child: const Text('ثبت سوارشدن +۱')),
        ]),
        const SizedBox(height: 8),
        const Text('برای عملیات واقعی، ثبت مسافر باید با احراز هویت و ثبت رویداد در سرور انجام شود.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ]),
    ),
  );

  Widget _adminPanel() => const Card(
    child: Padding(
      padding: EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('پنل مدیریت', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        SizedBox(height: 10),
        ListTile(leading: Icon(Icons.route_outlined), title: Text('مدیریت کروکی‌ها'), subtitle: Text('مسیر دستی یا مسیر ثبت‌شده روی نقشه')),
        ListTile(leading: Icon(Icons.groups_outlined), title: Text('کارکنان و رانندگان'), subtitle: Text('نسخه واقعی نیازمند حساب تأییدشده و نقش دسترسی است')),
        ListTile(leading: Icon(Icons.report_gmailerrorred_outlined), title: Text('گزارش‌ها و هشدارها'), subtitle: Text('تأخیر، انحراف مسیر، عدم حضور و ظرفیت')),
      ]),
    ),
  );

  Widget _routeCard() => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('کروکی و ایستگاه‌ها', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 6),
        Container(
          height: 110,
          width: double.infinity,
          decoration: BoxDecoration(color: Colors.teal.withOpacity(.08), borderRadius: BorderRadius.circular(14)),
          child: const Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.map_outlined, size: 34, color: Colors.teal),
              SizedBox(height: 6),
              Text('پیش‌نمایش نقشه در مرحله اتصال نقشه فعال می‌شود'),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        for (var i = 0; i < demoStops.length; i++)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(
              backgroundColor: demoStops[i].completed ? Colors.teal : Colors.grey.shade200,
              foregroundColor: demoStops[i].completed ? Colors.white : Colors.black87,
              child: Text('${i + 1}'),
            ),
            title: Text(demoStops[i].name),
            subtitle: Text('زمان نمونه: ${demoStops[i].time}'),
            trailing: demoStops[i].waiting > 0 ? Chip(label: Text('${demoStops[i].waiting} منتظر')) : null,
          ),
      ]),
    ),
  );

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }
}

-- PostgreSQL schema for Hamrah Palایشگاه
-- Apply only after reviewing with the organization's IT/security team.
create extension if not exists pgcrypto;

create type public.app_role as enum ('employee', 'driver', 'admin');
create type public.trip_status as enum ('scheduled', 'active', 'completed', 'cancelled');
create type public.passenger_status as enum ('reserved', 'boarded', 'alighted', 'no_show', 'cancelled');
create type public.report_status as enum ('open', 'reviewing', 'resolved', 'dismissed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  employee_code text unique,
  full_name text not null,
  role public.app_role not null default 'employee',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  fleet_code text not null unique,
  label text not null,
  capacity integer not null check (capacity > 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.routes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  route_geojson jsonb,
  allowed_deviation_m integer not null default 150 check (allowed_deviation_m >= 0),
  deviation_grace_seconds integer not null default 90 check (deviation_grace_seconds >= 0),
  active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.stops (
  id uuid primary key default gen_random_uuid(),
  route_id uuid not null references public.routes(id) on delete cascade,
  name text not null,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  sequence_no integer not null check (sequence_no >= 1),
  geofence_radius_m integer not null default 60 check (geofence_radius_m > 0),
  active boolean not null default true,
  unique(route_id, sequence_no)
);

create table public.trips (
  id uuid primary key default gen_random_uuid(),
  route_id uuid not null references public.routes(id),
  vehicle_id uuid not null references public.vehicles(id),
  driver_id uuid not null references public.profiles(id),
  shift_name text,
  planned_start timestamptz not null,
  planned_end timestamptz,
  actual_start timestamptz,
  actual_end timestamptz,
  status public.trip_status not null default 'scheduled',
  created_at timestamptz not null default now()
);

create table public.trip_bookings (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  passenger_id uuid not null references public.profiles(id),
  pickup_stop_id uuid not null references public.stops(id),
  dropoff_stop_id uuid not null references public.stops(id),
  status public.passenger_status not null default 'reserved',
  boarded_at timestamptz,
  alighted_at timestamptz,
  created_at timestamptz not null default now(),
  unique(trip_id, passenger_id),
  check (pickup_stop_id <> dropoff_stop_id)
);

create table public.vehicle_positions (
  id bigint generated always as identity primary key,
  trip_id uuid not null references public.trips(id) on delete cascade,
  driver_id uuid not null references public.profiles(id),
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  accuracy_m real,
  speed_mps real,
  heading_deg real,
  recorded_at timestamptz not null default now()
);
create index vehicle_positions_trip_time_idx on public.vehicle_positions(trip_id, recorded_at desc);

create table public.trip_events (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  stop_id uuid references public.stops(id),
  actor_id uuid references public.profiles(id),
  event_type text not null check (event_type in
    ('trip_started','stop_arrival','stop_departure','passenger_boarded',
     'passenger_alighted','trip_completed','route_deviation','delay','no_show')),
  details jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now()
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id),
  reporter_id uuid not null references public.profiles(id),
  category text not null check (category in
    ('route_deviation','late_arrival','missed_stop','capacity','driver_conduct','passenger_conduct','other')),
  description text not null,
  latitude double precision,
  longitude double precision,
  status public.report_status not null default 'open',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id),
  trip_id uuid references public.trips(id) on delete cascade,
  title text not null,
  body text not null,
  kind text not null,
  sent_at timestamptz,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

-- IMPORTANT:
-- Enable RLS on every table and add role-aware policies before production.
-- Do not ship service-role keys in the mobile application.
-- Location retention and visibility must be limited by company policy.
